<?php

/* @var $this yii\web\View */

$this->title = 'Dashboard';
?>
<div class="site-index">


    <div class="body-content">

        <div class="row">
            <div class="col-lg-4" style="background-color: lightblue; margin-left: 60px;">
                <h2>Vehicle Information</h2>

               

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=vehicleinformation">More... &raquo;</a></p>
            </div>
            <div class="col-lg-4" style="background-color: lightblue; margin-left: 70px; ">
                <h2>Bill Upload</h2>

                

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=billupload%2Findex">More... &raquo;</a></p>
            </div>
          
        </div>
        <div class="row" style="padding-top: 50px;">
         <div class="col-lg-4" style="background-color: lightblue; margin-left: 60px;">
                <h2>Project Register</h2>

        

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=projectregister">More.. &raquo;</a></p>
            </div>
              <div class="col-lg-4" style="background-color: lightblue; margin-left: 70px;">
                <h2>Bank Gurantee</h2>

                

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=bankgurantee">More.. &raquo;</a></p>
            </div>


    </div>
    <div class="row" style="padding-top: 50px;">
         <div class="col-lg-4" style="background-color: lightblue; margin-left: 60px;">
                <h2>Running Project IPC</h2>

        

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=runningprojectipc">More.. &raquo;</a></p>
            </div>
              
              
         <div class="col-lg-4" style="background-color: lightblue; margin-left: 60px;">
                <h2>Project Status</h2>

        

                <p style="padding-left: 100px;"><a class="btn btn-default" style="color: red;" href="http://localhost/construction-system/backend/web/index.php?r=site/projectstatus">More.. &raquo;</a></p>
            </div>
    

    </div>
</div>
