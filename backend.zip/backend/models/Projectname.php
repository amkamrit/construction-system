<?php

namespace backend\models;

use yii\db\ActiveRecord;

class Projectregister extends ActiveRecord
{
}
